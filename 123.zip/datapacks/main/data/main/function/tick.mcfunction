execute as @a[tag=!joined] at @s run function main:on_join
function main:kill_areas/tick
function main:spawn/tick
function main:services/tick
function main:levels/tick
function main:snake/tick

execute as @a[tag=playsound_teleport] at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 100 1 0
tag @a remove playsound_teleport

#onground
scoreboard players set @a[nbt={OnGround:1b}] onGround 1
scoreboard players set @a[nbt={OnGround:0b}] onGround 0

#firedamage
#counts down after the flames go out, so a death in the next second still counts as lava
execute as @a if predicate main:on_fire run scoreboard players set @s firedamage 20
execute as @a[scores={firedamage=1..}] unless predicate main:on_fire run scoreboard players remove @s firedamage 1

#bouncedeath
#set while in a bounce level's pit, counts down after leaving so dying to the
#impact itself still counts as a bounce rather than a plain fall
execute as @a[scores={bounceDeath=1..}] run scoreboard players remove @s bounceDeath 1